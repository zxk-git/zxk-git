===========
Metrics
===========

Classification & Segmentation
==============================


Accuracy
---------------------------------

.. autofunction:: tllib.utils.metric.accuracy


ConfusionMatrix
---------------------------------

.. autoclass:: tllib.utils.metric.ConfusionMatrix
   :members:
