=====================================
Feature Alignment
=====================================

.. toctree::
    :maxdepth: 3
    :caption: Feature Alignment
    :titlesonly:

    statistics_matching
    domain_adversarial
    hypothesis_adversarial
