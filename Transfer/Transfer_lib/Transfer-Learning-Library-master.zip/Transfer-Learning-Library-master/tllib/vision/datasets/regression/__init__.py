from .image_regression import ImageRegression
from .dsprites import DSprites
from .mpi3d import MPI3D